<?php
if(isset($_POST['send_email'])) {
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$message = $_POST['message'];
	if($name=="") {
		$nameMsg = "<br><span style='color:red;'>Your name cannot be blank.</span>";
	}
	if($phone=="") {
		$phoneMsg = "<br><span style='color:red;'>Your phone number cannot be blank.</span>";
	}
	if($email=="") {
		$emailMsg = "<br><span style='color:red;'>Your email address cannot be blank.</span>";
		} else {
		$inserted = "<h3>Your message has been sent!</h3>";
		$inserted .= "<p><a href='home.php'>Return to home page</a></p>";
	} //end if
}//end if
?>
<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	function validateForm() {
		var name = document.form1.name.value;
		var email = document.form1.email.value;
		var phone = document.form1.phone.value;
		var nameMsg = document.getElementById('nameMsg');
		var emailMsg = document.getElementById('emailMsg');
		var phoneMsg = document.getElementById('phoneMsg');
		if(name=="") {nameMsg.innerHTML = "Your name cannot be blank."; return false;}
		if(email=="") {emailMsg.innerHTML = "Your email address cannot be blank."; return false;}
		if(phone=="") {phoneMsg.innerHTML = "Your phone number cannot be blank."; return false;}
	}
</script>
</head>

<body>
<?php include('includes/header.inc'); ?>
<?php include('includes/nav.inc'); ?>

<div id="wrapper">


	<aside>
	
	</aside>


	<section>
	<h2>Contact Us</h2>
	<?php
		if(isset($_POST['send_email'])){
			// Put form data into variables
			$name = $_POST['name'];
   			$phone = $_POST['phone'];
   			$email = $_POST['email'];
   			$message = $_POST['message'];

   			// Set the To: and From: fields
   			// Note - the header is needed to include the From field
   			$to = "camouflaged98002@yahoo.com";
   			$subject = "Contact mail from the website";
   			$from = $email;
   			$headers = "From: $from";
			$headers .= "Bcc: $from";
			$headers .= "Cc: $from";
 
   			// send the mail
   			mail($to, $subject, $message, $headers);
				}
	?>
		<?php if(isset($inserted)) {echo $inserted; } else { ?>
	<form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>" name ="form1" onSubmit="return validateForm()">
	<p>
		<label>Name:</label><br>
		<input type="text" id="name" name="name">
		<?php if(isset($nameMsg)){
			echo $nameMsg;
		} ?>
		<br><span id="nameMsg" style="color:red"></span>
	</p>
	<p>
		<label>Email:</label><br>
		<input type="text" id="email" name="email">
		<?php if(isset($emailMsg)){
			echo $emailMsg;
		} ?>
		<br><span id="emailMsg" style="color:red"></span>
	</p>
	<p>
		<label>Phone:</label><br>
		<input type="text" id="phone" name="phone">
		<?php if(isset($phoneMsg)){
			echo $phoneMsg;
		} ?>
		<br><span id="phoneMsg" style="color:red"></span>
	</p>
	<p>
		<label>Message:</label><br>
		<textarea id="message" name="message">
		</textarea><br>
	</p>
	<p>
		<input type="submit" name="send_email" value="Submit">
	</p>
	</form>
		<?php } ?>

	</section>

</div>
<?php include("includes/footer.inc");?>
</body>
</html>