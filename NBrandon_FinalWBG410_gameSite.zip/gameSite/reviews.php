
<!DOCTYPE html>
<html>
<head>
<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

	<?php include('includes/header.inc'); ?>
	
	<?php include('includes/nav.inc'); ?>


<div id="wrapper">

	<?php include('includes/aside.inc'); ?>

	<section>
	<h2>Product Reviews</h2>
	<table width="100%" cellpadding="5">
		<tr><th>Product Id</th><th>Comment</th><th>Review Date</th></tr>
		<?php
			include('includes/dbc.php');
			$query = "SELECT * FROM reviews ORDER BY id";
			$result = mysqli_query($con,$query);
			if($result == false){
				$error_message = mysqli_error();
				echo "<p>There has been a query error: $error_message</p>";
			}
			if(mysqli_num_rows($result)==0) {
				echo '<td align="center"><a href="add_review.php?id=' . $row['product_id'] . '">Write a Review</a>';
			}
			while($row=mysqli_fetch_assoc($result)) {
				echo '<tr align="center"><td>' . $row['name'] . '</td>';
				echo '<td align="center">' . $row['comment'] . '</td>';
				echo '<td align="center">' . $row['review_date'] . '</td></tr>';
			}
		?>
		</table>
	</section>

</div>

<?php include('includes/footer.inc'); ?>

</body>
</html>

