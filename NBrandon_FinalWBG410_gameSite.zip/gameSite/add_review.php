<?php
if(isset($_POST['add_review']))
   {
	   $name = $_POST['theName'];
	   $comment = $_POST['comment'];
	   $theID = $_GET['product_id'] ;
	   
	   if($name=="")
	   {
		  $nameMsg = "<br><span style='color:red;'> Your name cannot be blank.</span>";
	   }
	   if($comment=="")
	   {
		  $commentMsg = "<br><span style='color:red;'> Your email address cannot be blank.</span>";
	   }
	   else
	   {
		
		include('includes/dbc_admin.php');
		$query = "INSERT INTO reviews(name,comment,product_id) VALUES ('$name','$comment','$product_id')";
		$success = mysqli_query($con,$query);
		if($success)
		{
		$inserted = "<h2>Thanks!</h2><h3>Your review has been submitted!</h3>";
		}
		else
		{
		$error_message = mysqli_error($con);
        $inserted = " There was a database error: $error_message";
		exit($inserted);
	    }
	   }
    }
?>

<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
function validateForm()
{
    var theName = document.form1.theName.value;
	var comment = document.form1.comment.value;
	

	var nameMsg = document.getElementById('nameMsg');
	var commentMsg = document.getElementById('commentMsg');
	var product_idMsg =  document.getElementById('product_idMsg');

	
	
	if (theName=="") {nameMsg.innerHTML = "Your name cannot be blank."; return false;}
	if (comment=="")   {commentMsg.innerHTML = "Your comments cannot be blank."; return false;}
	

}

</script>



<title>My Gaming Products Site</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php include("includes/header.inc");?>
<?php include("includes/nav.inc");?>

<div id="wrapper">


<aside>
<?php include("includes/aside.inc");?>
</aside>

 
<section>
<h2>Review</h2>
	
	 <?php if(isset($inserted)) {echo $inserted;}else{ ?>
	
	<form method ="post" action="<?php echo $_SERVER['PHP_SELF']?>" name="form1" onSubmit ="return validateForm()">
	
	<p>
	  <label>Product Name</label><br><input type="text" id="theName" name="theName">
	  <?php if(isset($nameMsg))
	  {
		echo $nameMsg;
	  } ?>
	  <br><span id="nameMsg" style="color:red"></span>
	</p>
	<p>
	   <label>Comments:</label><br>
	   <?php if(isset($commentMsg))
	  {
		echo $commentMsg;
	  } ?>
	   <textarea id="comment" name="comment">
	</textarea><br>
	</p>
	
	<p>
	<input type="submit" name="add_review" value="Submit">
	</p>
	 
	</form>
	<?php } ?>
	


</section>

</div>

<footer>
<p>Footer Text | &copy; My Site | Year (xxxx)</p>
<?php include("includes/footer.inc");?>
</footer>

</body>
</html>